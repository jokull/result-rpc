# result-rpc architecture

## Purpose

result-rpc is an RPC layer for React — one library covering:

- composing typed `Result` values;
- declaring RPC procedures and their complete recoverable error sets;
- encoding those results across a network boundary;
- resolving process services as a memoized dependency graph;
- growing and narrowing request context through middleware and layers;
- expanding server errors with client and environment failures;
- caching and observing calls through a reactive query runtime;
- owning failures at the right tree position through shells — error
  boundaries generalized to values.

> **0.3 update:** the Result runtime is now better-result 3.0 as a dependency
> (protocol v2, `{ status }` envelope, per-procedure Result codec). This
> document tracks the current architecture.

It replaces the public roles of better-result, tRPC, and React Query, and
deliberately nothing more: routing, SSR, and bundling belong to whatever owns
the tree. React bindings are first-class and intended — the shell model is a
React idea. An initial release may use `@tanstack/query-core` as a private
scheduling and cache engine, but no TanStack type or `data | error` API crosses
the result-rpc public boundary.

## Architectural invariants

These are requirements, not aspirations:

1. Every recoverable failure exposed to application code is a reified result-rpc
   `TaggedError` instance from a closed operation-specific union.
2. Every tagged error is downgraded to its canonical structural form at the wire,
   validated against its declared definition, and reified before it is exposed by
   the receiving runtime.
3. Application-defined prototypes, transmitted stacks or causes, arbitrary thrown
   values, and ambient `Error` types never enter the public recoverable failure
   algebra. The library-owned `TaggedError` prototype and serializer-supported
   built-ins such as `Date` are reconstructed locally.
4. A procedure's declared error registry is the authority for what may cross the
   server boundary.
5. Unknown server exceptions and undeclared or invalid errors are logged and
   replaced with a sanitized `server/internal` error.
6. Client transport and protocol failures extend the procedure union rather than
   forming a second error channel.
7. The query cache stores successful domain values. It does not store `Err` as
   successful query data.
8. Query lifecycle, cancellation, and connection state are modeled separately from
   operation failure.
9. Retry policy has one owner for any operation attempt.
10. Local/server-side calls can be run with the same encode/decode semantics as
    remote calls.
11. Narrowing is subtractive and never additive: a shell may only remove error
    definitions an enclosing layer provably owns. The contract union is unchanged by it.
12. An error removed from an operation's union never surfaces as that operation's
    terminal failure state.

## System shape

The project should ship as one versioned npm package with subpath exports. Internal
modules remain separate so dependencies flow in one direction and can be tested in
isolation.

```mermaid
flowchart TD
    Wire[wire grammar and codecs]
    Result[Result algebra]
    Contract[errors, middleware, procedures, router]
    Protocol[protocol envelopes and codecs]
    Server[server runtime and adapters]
    Client[typed client and transports]
    Query[reactive query runtime]
    Bindings[React bindings]

    Wire --> Result
    Wire --> Contract
    Result --> Contract
    Wire --> Protocol
    Contract --> Protocol
    Contract --> Server
    Protocol --> Server
    Contract --> Client
    Protocol --> Client
    Client --> Query
    Query --> Bindings
```

No upward dependency is allowed. In particular:

- the Result algebra knows nothing about RPC or queries;
- procedure contracts know nothing about HTTP or React;
- protocol codecs know nothing about fetch or server frameworks;
- the client knows nothing about React;
- React bindings contain no protocol logic.

Procedure construction has one lower-level declaration algebra shared by the
root contract builder and the executable server builder. It owns input/output
codecs, error maps, header capability, pagination, and cache declarations;
server execution adds only middleware and handlers. `affects`/`writes` mappers
remain functions of the exact decoded input until the terminal manifest compile
step. Once a mapper binds an input, replacing that input codec is an illegal
builder state rather than a stale callback waiting to fail at runtime.

Factories, procedures, clients, and routers each retain one hidden associated
type record. Consumers project facts from those records instead of re-matching
positional generics or `_def` structure. The factory record is invariant so the
first factory argument remains the source of request-context inference; later
middleware and contract arguments validate it with `NoInfer` rather than
widening it and trying to infer the context again.

## Public package surface

Suggested exports:

```ts
import { ok, err, match, matchError, error, wire, rpc } from "result-rpc";

import { createFetchHandler, createServerClient, serverRpc } from "result-rpc/server";

import { createBrowserClient, fetchTransport, batchFetchTransport } from "result-rpc/client";

import {
  ResultRpcProvider,
  ResultSuspense,
  useResultQuery,
  useResultSuspenseQuery,
  useResultMutation,
  useResultSubscription,
} from "result-rpc/react";

// The react-free entry, for server code that must not pull React in.
import { createQueryRuntime } from "result-rpc/query";

import { createParityClient } from "result-rpc/testing";
```

The root entry is the contract language — everything safe on both sides of the
wire (results, codecs, errors, layer declarations, services, and the contract-only
`rpc` builder). Server middleware, implementations, and routers begin at
`serverRpc`. Each runtime
then has exactly one entry: `/server`, `/client`, `/react`, `/testing`.

Subpath exports are organizational boundaries, not independently versioned
packages. Contracts, server, client, and UI cannot drift onto incompatible protocol
or error-definition versions.

## Wire layer

### Versioned transparent serializer

The protocol uses a pinned devalue implementation behind a result-rpc serializer
version. It transparently round-trips the values Svelte users expect: `undefined`,
non-finite numbers, `-0`, `Date`, `BigInt`, `RegExp`, `Map`, `Set`, repeated
references, cycles, URLs, array buffers, and typed arrays.
When `Temporal` is installed or native in both runtimes, its standard value types
round-trip through the same pinned profile as well.

Devalue does not promise format stability across releases, so its package version
is not itself the protocol contract. result-rpc pins the implementation, sends a
serializer version in the content type, and changes that version only with an
explicit compatibility strategy.

Unsupported functions, symbols, promises embedded in settled values, and arbitrary
class instances fail serializer preflight. Versioned custom reducer/reviver
profiles are reserved for a later protocol version; the initial release has one
pinned serializer profile and cannot be configured one-sidedly.

Encoded request, response, frame, hydration, and tagged-error byte limits have
conservative defaults. Custom procedure codecs enforce domain-specific string and
collection bounds; aggregate byte limits remain effective for cyclic graphs where
naive depth traversal is unsuitable.

### Codec abstraction

```ts
interface WireCodec<Input, Output> {
  readonly kind: string;
  encode(input: Input): DecodeResult<Output>;
  decode(value: unknown): DecodeResult<Input>;
}
```

`DecodeResult` is an internal Result whose failure contains structured codec issues.
Raw hostile input must not be copied into an application-visible error.

The library supplies primitives, rich built-ins, arrays, records, objects, literals,
unions, optional object keys, and a serializer-preflight codec for recursive graphs.
Adapters for Standard Schema may be added, but every validated value is also checked
by the actual transport serializer. A validator's output type alone is not proof of
wire compatibility.

## Error model

### Runtime value

```ts
abstract class TaggedError<
  Tag extends string = string,
  Data extends WireValue = WireValue,
> extends Error {
  private readonly nominalBrand: void;
  readonly _tag: Tag;
  readonly data: Data;
  toJSON(): EncodedTaggedError<Tag, Data>;
  [Symbol.iterator](): Generator<Err<this>, never, unknown>;
}

interface EncodedTaggedError<Tag extends string, Data extends WireValue> {
  readonly _tag: Tag;
  readonly data: Data;
}
```

The runtime value is a frozen, nominal `Error` subclass. Its public behavior is
faithfully reconstructed on either side of a result-rpc boundary: definition
guards, `Error` interoperability, typed data, `toJSON`, and direct `yield*` inside
`gen`. The client receives a new instance, never the server object's identity.

The wire carries only `EncodedTaggedError`: a prototype-free `_tag` plus declared
`data`. Server stacks and causes never cross. A client-side stack belongs to the
new local instance and must not be represented as the server stack. Ordinary data
is deeply frozen; serializer-supported built-ins are defensively copied by their
codecs. JavaScript cannot freeze mutable internal slots such as `Date#setTime`, so
readonly usage remains part of the contract. Localization normally happens by
`_tag`; a human-readable message may be deliberately declared in `data`.

### Definition

```ts
interface ErrorDefinition<
  Tag extends string,
  Input,
  Data extends WireValue,
  Visibility extends "public" | "private",
> {
  readonly tag: Tag;
  readonly codec: WireCodec<Input, Data>;
  readonly policy: ErrorPolicy<Visibility>;

  (input: Input): TaggedError<Tag, Data, Visibility>;
  is(value: unknown): value is TaggedError<Tag, Data, Visibility>;
  decode(value: unknown): DecodeResult<TaggedError<Tag, Data, Visibility>>;
}

interface ErrorPolicy<Visibility extends "public" | "private"> {
  readonly httpStatus?: Visibility extends "public" ? number : never;
  readonly retry: "never" | "transient" | "after";
  readonly visibility: Visibility;
  readonly severity: "debug" | "info" | "warning" | "error";
}
```

Each definition owns a private `TaggedError` subclass. Router composition compares
definition identity and tag:

- reusing the same definition is allowed;
- two different definitions with the same tag are a startup error;
- tags must be namespaced strings such as `doc/not-found`;
- framework tags reserve the `client/`, `server/`, `protocol/`, and `control/`
  namespaces.

Each definition owns a private `TaggedError` subclass. Router composition compares
definition identity and tag:

- reusing the same definition is allowed;
- two different definitions with the same tag are a startup error;
- tags must be namespaced strings such as `doc/not-found`;
- framework tags reserve the `client/`, `server/`, `protocol/`, and `control/`
  namespaces.

The `.is` method checks for an instance of that exact definition. `.decode` is the
trust boundary: it validates an encoded tag and data codec, then constructs the
matching instance. A shape-compatible object is neither accepted by `err()` at
compile time nor accepted from a handler at runtime.

### Why the boundary union is closed (`DeclaredProcedureErrors`)

A procedure handler must return `Result<Output, DeclaredProcedureErrors>` — the
exact union of the definitions declared on that procedure (plus the framework
`server/internal` and `server/bad-request`). It deliberately does **not** accept
`Result<Output, AnyTaggedError>`, for three reasons:

1. **The compile-time contract is the feature.** The closed union is what makes
   `switch (query.error._tag)` exhaustive, what shells subtract, and what
   `.errors()` gates. A handler that could return any tagged error would compile
   an undeclared tag, and the boundary would then sanitize it to
   `server/internal` — the type says one error, the wire says another. That
   type/runtime divergence is worse than a compile error.
2. **Sanitization is a backstop, not a policy.** The runtime registry check
   exists because `any`, assertions, and malformed handler returns bypass
   typing; it is defense-in-depth for the type layer, not a replacement for it.
   Loosening the type would make the runtime the _only_ gate and silently
   discard the library's headline diagnostic.
3. **The accumulation machinery derives from declared sets.** Middleware,
   layer, and shell unions accumulate only what is declared; an open error
   channel would leak undeclared tags into derived unions at the type level.

This is a boundary decision, not a runtime decision: framework-internal
execution paths (`normalizeRuntimeResult`, `executeProcedure`'s erased
overload) use `Result<unknown, AnyTaggedError>` freely. Only the public
procedure contract is closed. Upstream adoption needs no loosening: a
better-result Result whose error is a result-rpc tagged error is declared in
`.errors({ ... })` and returned zero-copy; a foreign error is folded with
`mapError` before the boundary.

### Registry

Tags are flat, namespaced strings (`doc/not-found`); hierarchy is deliberate
non-goal because grouping happens by value — the definition maps shared by
procedures, middleware, shells, layers, and catalogs. The router build is the
registry: it collects every declared definition, rejects a tag bound to two
different definitions (reference identity), and exposes the result as
`router.errors`. Uniqueness at this level is required for ambient shell
claiming: a tag locates a candidate definition, then that exact definition must
recognize the reified instance. `defineErrors(namespace, specs)` derives
tags from keys (template-literal typed), so a tag string is written once or
never.

### Input rejection tier

Malformed input is a `server/bad-request` (400, public, `severity: "warning"`)
carrying bounded path/message issues and never echoing values — emitted by both
the HTTP handler and parity execution, with no incident. `server/internal`
remains reserved for defects. Both are framework-namespace tags every client
union includes and `defectErrors` claims.

### Observability

One structured stream per tier, values excluded by construction:

- **Client** — `createBrowserClient({ onEvent })`: `call`/`success`/`failure`/`retry`
  from the call pipeline (paths, tags, durations), plus `claimed` when a
  pausing shell holds a failure (path, tag, owner, `effect: "pause"`). Claim
  events emit at the same dedupe point as shell `onError` — once per newly held
  error per observer.
- **Pausing shells** — `onError` is the holding reaction. A failed recovery is
  a fresh attempt and may report the same owned error again.
- **Escalating shells** — the nearest React error boundary observes the exact
  tagged instance; there is no holding, shell reaction, or `claimed` event.
- **Server, declared** — `createFetchHandler({ onError })`: every declared
  error response with its `ErrorPolicy`, path, and status; `severity` exists
  for this tap.
- **Server, defects** — `onInternalError`: the only tap that ever sees causes
  and stacks.

`tap`/`tapError`/`tapBoth` observe a single Result inline and return it
unchanged; a throwing tap is a defect in the tap and propagates as an
exception rather than becoming an Err.

### Built-in errors

The first version should define at least:

```ts
type FrameworkError =
  | ServerInternal
  | ClientOffline
  | ClientNetworkFailure
  | ClientTimeout
  | ClientHttpFailure
  | ClientProtocolViolation
  | ClientDecodeFailure;
```

`server/internal` contains an opaque incident ID and no original exception text.
Transport errors contain only allow-listed, bounded metadata. Response bodies,
headers, cookies, stacks, causes, and arbitrary URLs are never embedded.

## Result layer

### Representation

```ts
type Result<T, E extends TaggedError> =
  Readonly<{ ok: true; value: T }> | Readonly<{ ok: false; error: E }>;
```

The enumerable representation is a small discriminated value with a
non-enumerable iterator for `gen`. RPC decoding reconstructs that behavior. There
is no misleading shallow `.serialize()` method.

### Composition

Standalone functions preserve error unions:

```ts
map<A, B, E>(result: Result<A, E>, fn: (value: A) => B): Result<B, E>

andThen<A, B, E1, E2>(
  result: Result<A, E1>,
  fn: (value: A) => Result<B, E2>,
): Result<B, E1 | E2>

mapError<A, E1, E2>(
  result: Result<A, E1>,
  fn: (error: E1) => E2,
): Result<A, E2>
```

`matchError` is exhaustive over `_tag`.

Generator composition accepts both yieldable Result values and TaggedError
instances. Neither runtime object is serialized naively: the RPC protocol writes
its canonical structural envelope and reconstructs the iterator on decode.

## Service layer

`defineService`/`resolveServices` own process-lifetime dependencies (pools,
bindings, clients): an async dependency graph resolved once at startup, memoized
by definition reference identity, cycle-rejected with the offending path. The
resolved record is intended as the root context `createContext` closes over.
Services never produce wire errors — construction failure is a process defect,
not a request failure. This is the deliberate split from request middleware,
which is ordered, per-request, and failure-carrying.

## Contract layer

### Procedure definition

The core type is conceptually:

```ts
interface ProcedureDef<
  Context,
  Input,
  Output,
  ErrorDefinitions,
  Kind extends "query" | "mutation" | "subscription",
> {}
```

Builders accumulate context, input/output codecs, metadata, and error definitions.
The handler must return:

```ts
Result<Output, ErrorOf<ErrorDefinitions>>;
```

or its promised equivalent.

Errors are declared before the handler and are authoritative. The implementation
cannot widen a contract by returning an arbitrary tagged object. Code-first
inference may infer success output, but never infers permission for a new error to
cross the wire.

### Middleware

Middleware may declare dependencies with `.after(dep)`: the dependency's output
context becomes the handler's input, its error definitions merge into the
middleware's, and `.use()` flattens the chain in dependency order, deduplicating
by reference identity. The `_types.inputContext` phantom is contravariant
(encoded as a function parameter) so a middleware needing less context is
assignable where more is available — and one needing more is rejected.

A middleware can:

- require and extend context;
- declare errors it may return;
- observe results without changing their wire identity;

Middleware errors union with procedure errors. Collision rules are identical to
router composition. Middleware cannot silently replace a procedure's definition.
Each handler receives only its own error constructors, while its dependencies'
errors still accumulate into the procedure union. `next` likewise accepts only
the middleware's declared context contribution; the executor performs the
monotonic merge.

The type graph mirrors that runtime split. Error definitions accumulate as a
union of source maps, which naturally deduplicates shared diamond ancestry;
the keyed catalog is materialized only where a consumer asks for it. Immediate
dependency records omit their own ancestry because the runtime graph already
owns it. The committed type profile measures chains and context/error diamonds
through depth 15, including terminal-slope acceleration, so a superficially
better average cannot hide an explosive tail.

```ts
const authenticated = serverRpc
  .middleware()
  .errors({ Unauthorized })
  .use(async ({ context, next, errors }) => {
    const user = await authenticate(context.request);
    if (!user) return err(errors.Unauthorized({}));
    return next({ context: { user } });
  });
```

### Router manifest

Contract construction produces an immutable browser-safe manifest containing, per path:

- operation kind;
- input and output codecs;
- complete error registry;
- error policies.

`server.implement(contract)` attaches the server-only middleware chain and handler.
The server router is therefore a separate runtime object and cannot accidentally
pull repository, authentication, or database code into the browser bundle. The
shared manifest drives client type inference, decoding, documentation, test
clients, and query-key generation; the implementation router drives dispatch.

## Server runtime

### Execution pipeline

```text
route request
  -> validate protocol envelope
  -> decode input
  -> construct context
  -> execute middleware
  -> execute handler
  -> validate returned Result
  -> authorize and encode its error, or encode success
  -> write response
```

Every stage is inside one outer defect boundary.

Expected validation failures use declared framework or procedure errors. An
unexpected throw, rejected promise, undeclared tag, invalid tagged payload, invalid
success output, or encoder defect follows the internal-failure path:

1. generate an incident ID;
2. log the original value, stack, request context, and procedure path through the
   observability interface;
3. emit a valid sanitized `server/internal` envelope;
4. avoid recursively invoking application middleware while handling the failure.

If even the internal envelope cannot be encoded, the adapter emits a minimal static
500 response with a protocol-valid fixed payload.

### Server adapter

The initial adapter consumes and produces Web Standard `Request` and `Response`,
so it can be mounted directly in Bun, Deno, Cloudflare Workers, and modern Node
framework route handlers without runtime-specific result-rpc packages.

The deployment integration owns:

- routing and method checks;
- request body and response size limits;
- optional compression negotiation;
- disconnect-to-abort propagation.

They do not own error classification or serialization policy.

### Observability

Observability receives richer server-local events than clients receive:

```ts
interface FailureEvent {
  incidentId: string;
  procedurePath?: string;
  phase: "input" | "context" | "middleware" | "handler" | "output" | "error";
  cause: unknown;
}
```

The logger implementation is responsible for redaction and retention. Neither the
public TaggedError nor its encoded wire form contains this event.

## Protocol layer

### Versioning

Every request communicates a major protocol version through content type or a
dedicated header. Minor additions must be backward-compatible. Unknown major
versions fail before procedure dispatch.

### Envelopes

Conceptually:

```ts
interface SuccessEnvelope {
  readonly v: 1;
  readonly ok: true;
  readonly value: WireValue;
}

interface FailureEnvelope {
  readonly v: 1;
  readonly ok: false;
  readonly error: {
    readonly _tag: string;
    readonly data: WireValue;
  };
}
```

HTTP status is derived from the definition policy. It is not used as the error's
semantic discriminant. Clients still inspect status first so intermediary-generated
failures can be distinguished from valid result-rpc envelopes.

### Binaries are out of band

There is no file transport. Every request carries the single protocol
content-type (`application/result-rpc+devalue`), which is not a CORS-simple type
— so a browser cannot send it cross-origin without a preflight the server never
grants. That uniform content-type requirement is the CSRF defense, and it holds
precisely because no multipart/`FormData` path exists to speak a simpler type.
Binary payloads are handled by object storage out of band (presigned PUT to
R2/S3/a mounted route); the RPC contract carries only a typed reference (a
bucket key). This removes the multipart CSRF and unbounded-`formData()` DoS
surfaces entirely, at no cost to the contract's type safety.

### Decode trust boundary

For a failure response, the client:

1. checks content type, response limits, and envelope structure;
2. verifies the protocol version;
3. looks up `_tag` in the procedure plus framework registry;
4. decodes `data` using that exact definition;
5. constructs the declared `TaggedError` instance only after successful decoding.

No transmitted `defined`, `inferable`, or type-name flag is trusted. Unknown tags
become `client/protocol-violation`; bad data for a known tag becomes
`client/decode-failure`.

### Batching

A batch is a transport optimization, not a new procedure type. Each item has its
own ID and envelope. Declared failures remain per operation.

A shared transport failure produces the same client boundary tag for each affected
operation. Cancelling one item only aborts the shared request once all remaining
items are cancelled or detached.

The batch transport itself never retries. Each operation's query, subscription, or
direct-call owner applies its tag policy once; retry attempts that become ready in
the same microtask may naturally coalesce into a new batch.

### Streaming and subscriptions

Streams use framed, versioned messages with per-connection sequence IDs. The
operation has two orthogonal states:

- connection lifecycle: connecting, open, reconnecting, paused, closed;
- latest event Result, or a terminal tagged failure.

A transient disconnect that will be reconnected is lifecycle state, not a terminal
`Err`. The initial protocol restarts the subscription after reconnect; applications
needing deduplication include an event ID in the declared output. Once retry policy
is exhausted, the final connection failure is projected into the operation's
client error union.

## Client runtime

### Call pipeline

```text
validate and encode input
  -> transport request
  -> classify cancellation/network/HTTP
  -> validate protocol envelope
  -> decode success or registered error
  -> return Result<T, ProcedureError | ClientBoundaryError>
```

The default client resolves every recoverable outcome:

```ts
Promise<Result<Output, DeclaredErrors | FrameworkErrors>>;
```

There is no public `TRPCClientError`, `ThrowableError`, or `unknown` fallback.

The initial release deliberately omits an `unwrap` facade. Integration boundaries
can explicitly throw `result.error` when required without introducing a library
error class or a second error shape.

### Transport classification

Classification order prevents ambiguous failures:

1. explicit cancellation;
2. library-owned timeout;
3. browser-known offline state associated with a failed attempt;
4. fetch/network rejection;
5. non-success HTTP without a valid result-rpc envelope;
6. malformed envelope or unsupported protocol version;
7. tag or payload decode failure.

The built-in transport never adds the original cause to the returned tagged error.

### Cancellation

Cancellation is control flow, not a recoverable operation error. Internally it uses
one library-owned `control/cancelled` sentinel so fetch transports, batching, the
query engine, and subscriptions can recognize it without relying on platform
`AbortError` identity.

The sentinel is tagged and structurally safe, but excluded from procedure and
client error unions. Direct cancellable calls document that abort rejects with the
sentinel; the query runtime consumes it and transitions lifecycle state without
publishing a failure. Calls without a cancellation signal always resolve a Result
unless a client programming invariant is violated.

### Browser, server, and parity clients

One internal callable algebra maps a router to procedures and adds the boundary
error union supplied by its environment:

- `createBrowserClient({ contract, transport })` crosses the real protocol and
  adds server plus browser boundary errors.
- `createServerClient(router, { context })` runs in-process and adds only
  `server/bad-request` and `server/internal`.
- `createParityClient(router, { context })` is the wire-faithful test client: it
  connects the real fetch handler to the browser client without opening a socket.

Server rendering uses the direct server client. Protocol and serialization tests
use the parity client.

## Reactive query runtime

### Ownership

result-rpc owns query keys, cache-facing types, query state, mutation state,
subscription state, retry dispatch, hydration, and framework bindings.

The first engine adapter may use `@tanstack/query-core` privately. All references
to its observers, errors, statuses, and options terminate inside the query module.
A small internal `QueryEngine` port allows later replacement, but the port should
model result-rpc semantics rather than mirror TanStack's entire API.

### Cache rule

Successful values are cached as `T`. Tagged failures use the engine's internal
failure mechanism so retries, failure counts, pause/resume, and error-boundary
integration work correctly. `Result<T, E>` is never treated as successful cache
data.

The internal query function is equivalent to:

```ts
async function execute(): Promise<T> {
  const result = await client.procedure(input);
  if (result.isErr()) throw result.error;
  return result.value;
}
```

This rejection is private control flow inside the engine. Public observers project
it back into the same tagged Result union.

### Public query state

```ts
type QueryState<T, E extends TaggedError> =
  | {
      state: "pending";
      fetch: "fetching" | "paused";
    }
  | {
      state: "success";
      value: T;
      fetch: "idle" | "fetching" | "paused";
    }
  | {
      state: "failure";
      error: E;
      previous?: T;
      fetch: "idle" | "fetching" | "paused";
    };
```

`previous` preserves usable cached data after a failed background refetch. It does
not create another failure channel. The state also exposes refetch, timestamps,
failure count, staleness, and invalidation controls without exposing raw engine
`data` or `error` properties.

Offline pausing remains `fetch: "paused"`. It becomes `client/offline` only when a
configured policy settles the attempt as a failure.

### Retry

The query runtime is the retry owner for queries and mutations executed through it.
It obtains policy from the registered error definition, not by parsing HTTP status
or message strings.

Default behavior:

- domain, authentication, authorization, validation, not-found, protocol, and
  decode errors do not retry;
- network, timeout, and explicitly transient server errors use bounded backoff;
- retry-after errors expose validated delay data through their definition;
- offline work pauses rather than consuming attempts;
- cancellation consumes no retry budget.

The core client does not also retry when invoked by the query runtime. Direct calls
may opt into a standalone retry executor using the same policies.

### Mutations

Mutations use the same tagged union and public Result projection. They additionally
model submitted variables, optimistic context, and reset state. Optimistic updates
must register rollback behavior; a tagged mutation failure triggers rollback before
observers receive the final failure state.

Mutation cancellation support is explicit because platform transports cannot
always undo server-side effects after dispatch.

### Hydration and persistence

result-rpc owns a versioned cache codec. Hydration validates:

- cache format version;
- procedure/key identity;
- successful data codec;
- serializer payload bounds.

The initial release dehydrates successful query data only, so failures do not enter
the cache persistence format. Any future failed-query persistence must use the same
definition-controlled downgrade and reification path as RPC decoding.

Failed queries, cancellation, and transient connection state are never persisted.

## React bindings

React bindings subscribe to the framework-neutral query runtime through
`useSyncExternalStore`. They provide:

- a provider for the runtime instance;
- suspense and non-suspense query hooks;
- mutation and subscription hooks;
- SSR preloading and hydration helpers.

Suspense throws the pending promise but returns failures through the ordinary
Result state after settlement.

### Client proxy

The client is a path-building proxy. It is await-safe: resolving a promise to a
proxy node reads `.then`, which the proxy follows only if the path exists in
the router; otherwise it returns `undefined` so thenable checks pass through.

### Shells

A shell is a declared layer of failure ownership. `defineShell` takes an error
definition map, an effect, an optional handler, and an optional `provide` that
builds the value the layer guarantees. `from:` links it to its enclosing layer.

The framework contributes three whole failure classes (transport, defect,
stale), so it ships their owners pre-assembled: `boundaryShells()` returns
`TransportShell` (pause), `DefectShell` (escalate), and `StaleShell` (default
reaction: reload), plus a `BoundaryProvider` composing all three. User shells
hang off `StaleShell`.

`BoundaryProvider` doubles as the browser bridge. A single shared
connectivity source (`src/connectivity.ts`: `online`/`offline`/`focus` +
`visibilitychange`, lazily attached, SSR-safe) serves three consumers: the
provider resumes `TransportShell`'s held failures on reconnect (and on focus
while failures are held — the probe for `navigator.onLine` lying "true");
the query runtime mounts its `QueryClient` so query-core's online manager
continues paused retries and paused mutations (stale refetch on focus and
reconnect stays disabled — browser events time failure resumes, not cache
freshness); and paused subscriptions reconnect off the same source.
`useConnectivity()` projects the two-source banner signal
(`online | offline | degraded`). Connectivity is a cause-side hint and never
mints, suppresses, or reclassifies an error tag.

The same source is the anti-thrash lever. The runtime installs it as the
online manager's event source via `setEventListener` and seeds the initial
state (the manager boots assuming online; its default setup listens on
`window`, absent in React Native and test runtimes). With accurate state and
the default `networkMode: "online"`, reads pause while offline instead of
instantly failing through their retry budget. Mutations are pinned to
`networkMode: "always"`: writes fail loud with `client/offline` rather than
being queued for silent delivery on reconnect. Two guards complete it:
`client/offline` is never retried on a timer while the browser still reports
offline (runtime retry default and the direct client's
`retry: "from-error-policy"` path), and focus-triggered shell resumes have a
5s cooldown so repeated alt-tabbing at a downed server cannot storm it.

### Explicit wire models with source proofs

The wire contract remains an explicit, browser-safe value. A model may call
`.$satisfies<Source>()` to prove that its selected fields exactly match any
upstream row or domain type while allowing private source fields to remain
absent. The source arrives through a type-only import: it catches drift but
cannot pull a database schema into a client graph or silently widen the wire.

Database failures are a separate concern. `result-rpc/db` ships `tryDb`, an
ORM-independent Result boundary that recognizes common driver constraint
codes as private `db/*` composition currency, collapsed to declared domain
tags at the procedure boundary.

Derivations deliberately NOT taken, evaluated against doctrine:

- **Form validators from models** — forms validate humans, wires validate
  applications; deriving form rules from column metadata is the 1:1
  forms-bridge mistake with a schema accent.
- **CRUD procedure scaffolding** (`crudFor(Model)`) — the contract is the
  reviewed artifact; generating procedures hides the error unions and
  blast-radius declarations that reviewers must see. Revisit only if a real
  codebase demonstrates the boilerplate.
- **Output codecs from RQB query configs** — couples the shared contract to
  server resolver internals; the alignment is already enforced by the type
  checker (handler returns must satisfy output codecs).

### Entity hardening (stress-test round)

The entity system was tested adversarially (urql Graphcache autopsy →
attack-vector mapping; 26 empirical probes in `tests/entity/`; a seeded
coherence oracle asserting active observers against a reference database).
The round produced these load-bearing mechanisms:

- **`shareStructural`** (model.ts) replaces query-core's `replaceEqualDeep`
  as the per-query `structuralSharing`: same fine-grained identity reuse,
  plus brand transfer onto every surviving object — retained old objects
  inherit the incoming side's brand (this is what makes SSR hydration
  entity-aware), and unbranded app-made copies recover the old side's brand
  when the model key matches. Without it, the first patch (or any refetch)
  evicted entities from the index — the one-shot-patch bug.
- **Hydrate-time normalization**: `hydrate()` re-decodes every hydrated
  query through its output codec immediately, so brands and the index exist
  before any observe.
- **Staleness preservation**: every framework write into the cache (patches,
  observe/hydrate normalization) preserves `dataUpdatedAt` and re-marks
  `isInvalidated` — a patch is entity-partial and must never satisfy a
  pending invalidation or reset the staleTime clock.
- **Entity-scoped rollback**: `updateEntity`'s rollback re-patches the
  captured entity value instead of restoring whole-query snapshots.
- **In-flight reconciliation**: patching a query with a fetch in flight
  cancels the fetch, re-applies the patch after the revert, and invalidates
  — the stale response never regresses fresher entity state, and whatever
  else it carried (membership) arrives via the follow-up fetch.
- **Reindex hygiene**: only data-bearing (`success`) cache events reindex;
  patch-driven writes suppress reindexing entirely (a merge cannot change
  membership).
- **Subscriptions write through**: a live event's decoded entities run
  `applyEntityWrites` like a mutation output.

Documented semantics pinned by test rather than fixed: racing mutation
responses apply in arrival order (reconcile contended entities with `touch`);
correlated fields not carried by a projection output stay stale until a
refetch; `structuredClone` strips brands (WeakMap identity); entity patches
do not reach a subscription's own latest result. Known cost: the hot-entity
extreme (one entity in 200 × 1k-row cached queries) patches in ~640ms —
path-precise patching (clone only ancestors of matches) is the roadmap lever.

### Declared invalidation

A mutation's `.affects(target, map?)` records `AffectsEntry` values in its
manifest (contract or procedure — `implement()` carries them over). The query
runtime resolves each target against the router the client was built from
(reference identity, `_def` identity, or shared input/output codec identity
for contract-declared targets on router clients) and invalidates on mutation
success: `map(input)` for one cache key, or every cached input without `map`.
`affects` is excluded from the contract digest — it is client cache behavior,
not wire shape — and only mutations may declare it.

### Validators and forms

`wire.standard(schema)` adopts any synchronous Standard Schema (Valibot, Zod,
ArkType) as a wire input codec — validation on both sides plus serializer
preflight; async schemas and one-way transforms are rejected by construction.
There is deliberately no codec→form direction: forms validate humans
(coerced strings, progressive feedback, a projection of the input) and wires
validate applications (typed, complete, hostile) — the shapes rarely
coincide, and a bridge that pretends otherwise fights the form library.
`fieldIssues` projects `server/bad-request` issues onto dot-joined
input-shaped paths; mapping those onto a form's own field names is the
application's mapping, made explicit.

### Entity identities

`defineModel(name, { key, shape })` wraps `wire.object(shape)` in a codec
whose decode brands entity objects (global WeakMap: object → model; inert on
the server, GC'd with the values) and exposes `pick()` projections that must
carry the key. The query runtime walks every success value (`collectEntities`)
to keep an entity → queries index off query-cache events, and applies writes
by identity: mutation output entities patch containing queries in place
(`patchEntity`: identity-matched replacement with container cloning — cycles,
shared references, and Map/Set members handled uniformly; the projection rule
merges only keys the cached object has, and patched objects are re-branded).
`.writes(Model, map)` and handler `touch(Model, id)` (carried on the response
envelope as `model:id` keys, never values) provide invalidation-only paths
for scalar outputs, cascades, and deletes. Membership remains declared via
`.affects()`. A normalized store as source of truth is a permanent non-goal:
it serves flexible queries and would cost exact per-procedure output types.

### Response headers are a declared capability

Batches do **not** stream. The handler awaits every procedure in the batch and
only then constructs the response, so a `set-cookie` written by any of them
lands. This is a decision, not an omission: streaming a batch would send the
response headers before its slowest procedure finished, and any header written
after that point would vanish.

tRPC is the worked example. Its `ctx.resHeaders` and our `context.headers` are
the same mechanism, and its non-streaming path has the same ordering we do. But
`httpBatchStreamLink` returns `new Response(stream, { headers })` _before_
awaiting the calls, so header writes inside a procedure mutate a `Headers` the
response has already copied. No error, no warning — swapping the link silently
breaks every cookie set from a mutation, which is why `responseMeta` exists and
why real codebases end up minting cookies there, ahead of knowing the result.

Rather than pick between "never stream" and "cookies are unreliable", the
capability is declared. `.headers()` on a procedure (or a middleware, which
then obliges its procedures to declare it, exactly as its errors do) records
`writesHeaders` in the contract manifest and adds `context.headers`.
Undeclared procedures have no `context.headers`, so the mistake is a type
error rather than a runtime surprise. The flag is part of the contract digest,
because a client and server disagreeing about it would resurrect the dropped
cookie across a deploy.

What this buys: a transport can decide _before dispatch_ how a call may be
batched. If a streaming batch is ever added, calls declaring `writesHeaders`
are excluded from it by a static fact instead of a convention.

Subscriptions reject `.headers()` outright. `executeSubscription` is an async
generator whose body — middleware included — first runs when the stream is
pulled, which is after the `Response` is returned. There is no window in which
a write could land, so offering one would be a lie.

### Contract skew

Every response carries the server's contract digest (`x-result-rpc-contract`),
computed from procedure paths, capabilities, complete structural codec schemas,
and error schemas with policies — identical for a router and the contract it
implements, replaceable with a `contractVersion` build stamp on both sides.
The stamp is required protocol evidence. Unary, batch, and stream clients turn
a missing or empty stamp into `client/protocol-violation`; custom transports
must preserve it and proxies must forward or expose the header. There is no
unstamped compatibility mode.
External Standard Schema/guard codecs supply an application-owned stable schema
id because their internals cannot be fingerprinted portably. The client compares
per response:
the first mismatch emits a `skew` ClientEvent, and a contract-shaped failure
(`server/bad-request`, `client/decode-failure`, `client/protocol-violation`,
`client/http-failure`) under mismatch is reclassified to `client/stale`
carrying the original tag. Reclassification is failure-gated and
mismatch-gated, so matching deployments and successful calls are never
affected. `client/stale` extends `ClientBoundaryError` and is claimed by the
built-in `StaleShell`.

Claiming and narrowing are two halves with different carriers:

**Claiming is ambient.** A mounted shell provider registers a claim entry in a
scope context; every base hook (`useResultQuery`, `useResultMutation`,
`useResultSubscription`, suspense) consults the mounted scope, innermost owner
first. A claimed definition therefore never becomes a terminal failure anywhere
beneath its owner, regardless of which hook observed it — the shell is a
monitor on all procedure activity below it. Tags index the registry; exact
definition predicates establish ownership. `useHeld()` aggregates
everything absorbed, not just shell-hook traffic.

Every pause holding also has a committed lease owner. Ordinary hooks use their
own effect lifetime. First-render Suspense children cannot commit cleanup, so
`ResultSuspense` owns their lease at the boundary; unmounting or resetting that
boundary retires all claims in its scope. Request settlement only populates the
cache and never acquires ownership asynchronously.

**Narrowing is carried by the shell _value_, not by tree position:**

- the exact definition chain is retained by walking `from:`; shell hooks
  distribute over the procedure union and remove only members whose full
  tag/data/visibility signature is claimed, without any hand-written union;
- a shell hook cannot be reached without importing the module that declares the
  layer's handler, so the subtraction is not a claim the type system takes on
  faith from context;
- mount position is verified at runtime — a provider outside its `from:` layer
  throws, and shell hooks eagerly assert their whole chain is mounted, so the
  narrowed union can never outrun its owners. Plain hooks outside any provider
  keep the full union and surface every failure; their union under a provider
  is a sound over-approximation (it may list tags that can no longer surface).

Definition-time checks reject a tag claimed twice in one chain and a shell that
claims nothing.

Projection rules for a claimed error:

| Effect     | Query                                                             | Mutation                                                                           | Subscription                             |
| ---------- | ----------------------------------------------------------------- | ---------------------------------------------------------------------------------- | ---------------------------------------- |
| `pause`    | `fetch: "paused"`; stale success is retained, otherwise `pending` | no retry; state returns to `idle`, `mutateAsync` rejects with the control sentinel | `connection: "paused"`, `result` cleared |
| `escalate` | reified `TaggedError` thrown during render                        | same                                                                               | same                                     |

Escalation throws the `TaggedError` itself rather than a wrapper, so a boundary
fallback can `matchError` on it. It creates no holding, calls no shell
`onError`, and emits no pause `claimed` event. The library does not introduce a
second public wrapper error shape.

Each shell instance owns a small store of the errors it is currently holding —
each with the retry handle its observer registered (query refetch, subscription
reconnect; mutations register none). `useHeld()` exposes the aggregate plus
`resume()`, which retries every holding. Layer shells resume automatically when
their context procedure's `updatedAt` advances (the value was re-established).
If a recovery attempt fails with an owned error, it creates a fresh holding and
may invoke the idempotent pause reaction again.

Teardown is specified: holdings release via each claim effect's cleanup as
observers unmount (child-first, so the node drains before the provider goes),
`onError` never re-fires on unmount, and a remount is a fresh node — a cached
failure encountered again is a new claim.

Each shell instance owns its aggregate through `useHeld()`. Connectivity is a property of the
application, not of any single operation, so the ambient tier is observed rather
than branched on.

### Layers

`defineLayer` is the shared declaration behind a shell that also has a server
half: a name, a context key, a `provides` wire codec, and an error map. Three
derivations close over that one declaration:

- `layer.middleware(app, resolve)` — server middleware adding the value to
  context under the key and contributing the union;
- `layer.procedure(app, ...middlewares)` — the context procedure (`{} -> value`
  with the layer union) whose handler is derived: it returns the value the
  middleware placed in context. Contract-first routers pass the shared
  `layer.contract(app)` ahead of the chain;
- `layerShell(layer, { from, procedure, onError })` — the React sibling: its
  Provider loads the value through the context procedure under the enclosing
  shells, provides it, and claims the layer union.

An empty error map declares an optional layer: it always establishes (a nullable
value) and its shell claims nothing. `layer.require({ provides, errors, refine })`
derives a required layer that narrows the same context key — `User | null`
becomes `User` — with middleware that needs no resolver and a union contributed
by the refinement. Context therefore grows and narrows monotonically through the
middleware chain, and the client onion mirrors it as nested providers.

`LayerShape` is the structural surface `layerShell` accepts, so base and refined
layers derive shells identically. The `procedure:` option also accepts a
selector `(client) => procedure`, resolved through the enclosing provider via
`useResultClient()` at render time — shells therefore define at module level,
before any client instance exists. The runtime exposes its `client` for this
and for router loader contexts.

## Router integration

Deliberately none in the package. Shells are providers and hooks, so any
router composes; the route-fragment pattern (shell Provider as route
component, layer prefetch as route loader) lives as app-owned glue in
`examples/05-router-glue/router-glue.tsx`. A layer shell's `resolveProcedure` property is the
one advanced export that makes such glue possible: it returns a layer shell's
context-procedure resolver so integrations can derive loaders.

## Security and resource limits

The core protocol enforces:

- aggregate request, response, frame, hydration, and tagged-error byte limits;
- maximum batch item counts;
- prototype-pollution-safe object decoding;
- redaction of secrets from logs and incident metadata;
- fixed public text for internal failures;
- no reflection of malformed payloads into returned errors;
- no client trust in server-supplied type assertions.

Deployment adapters additionally own origin/CSRF policy and platform-specific
handler or streaming-idle timeouts. Domain codecs own tighter string, array, map,
and nesting constraints where those limits are meaningful to the procedure.

Error visibility is a literal type carried by definitions and instances. Omitted
visibility resolves to `"public"`; definitions explicitly marked `"private"` are
rejected from procedure, middleware, and layer error maps at compile time. The
client's flattened error union therefore contains only public members. Runtime
validation repeats the boundary: a private error forced through JavaScript or an
unsafe cast is treated as undeclared and converted to `server/internal`.

## Testing architecture

### Compile-time tests

Assert that:

- non-tagged and non-wire error types cannot be declared;
- middleware and procedure errors form the expected union;
- collisions fail;
- exhaustive matching requires every tag;
- client boundary errors expand each procedure correctly;
- no public query type contains raw `Error`, `unknown`, `data`, or engine errors.

### Codec and protocol tests

- byte-level round docs for every built-in error;
- rich-value and cyclic round docs, repeated identity, unsupported functions and
  classes, malformed serializer payloads, and resource limits;
- hostile unknown tags and invalid payloads;
- protocol version mismatch;
- server exception sanitization;
- malformed proxy and intermediary responses.

### Runtime conformance coverage

Transport and Web Standard server tests cover success, declared failure, internal
failure, timeout, cancellation, batching, disconnect, streaming, and limits.

The query runtime tests cover retries, offline subscription pause/reconnect,
mutation cancellation, background refetch failure with `previous`, optimistic
rollback, dehydration, hydration, and hostile hydrated data.

### Type and runtime parity

The test suite collectively verifies observable Result and error-union parity through:

- remote HTTP client;
- batched client;
- parity server client;
- query runtime;
- SSR hydration.

### Type performance

TypeScript **7** is the development baseline (the native compiler; the same
project checks in ~0.24s versus ~2.1s on 5.9). The library compiles clean under
it, and the emitted declarations are validated for consumers on every build by
`publint` and `are-the-types-wrong`.

The property that matters for a typed-RPC library is not raw speed but **shape**:
what a consumer's compiler pays _per procedure_ must stay constant, because
superlinear growth is what eventually makes an API package unusable
(TypeScript's `ts7056` "inferred type exceeds the maximum length the compiler
will serialize" is the terminal form). `pnpm bench:types` generates a synthetic
consumer at three sizes, measures instantiations, and fails the build if the
marginal cost per procedure grows more than 15% against
`bench/baseline.json`.

Measured, at the time of writing:

- **Procedures scale linearly** — ~940 instantiations each, flat from 25 to 100.
- **Shape width is nearly free** — quadrupling an object codec's fields (20 → 80)
  costs about 4% more instantiations, because the mapped type is computed once
  per shape and cached.
- **Declaration emit is healthy** — a 60-procedure router emits without
  `ts7056`, with no `any` leaking into the public surface.
- The library requires **no `@types/node`**: a browser-only consumer compiling
  with `types: []` gets a clean build, so environment globals are read through
  `globalThis` rather than named directly.

One measured negative result worth recording, so it is not "optimized" again:
rewriting `ShapeInput`/`ShapeEncoded` from precomputed required/optional key
unions into per-key `as` remapping — which reads as the more modern form —
**regressed instantiations by 34%**. The helper form computes each key union
once and reuses it; the remapped form re-evaluates the conditional for every
key in both halves of the intersection.

## Initial implementation sequence

1. Wire grammar, limits, codec primitives, and reifying tagged-error definitions.
2. Plain Result algebra, exhaustive matching, and compile-time union tests.
3. Procedure/middleware/router contracts and collision-safe error registries.
4. In-process parity execution with server defect sanitization.
5. Versioned unary HTTP protocol, fetch transport, and client classification.
6. Query runtime backed privately by `@tanstack/query-core`.
7. React bindings and SSR hydration.
8. Batching.
9. Mutations and optimistic updates.
10. Streaming and subscriptions.
11. Protocol hardening and conformance audit.

Each phase must preserve the architectural invariants. In particular, batching,
streaming, SSR, and framework adapters cannot introduce a second error channel or
bypass the same codecs used by unary remote calls.

## Deliberate non-goals for the first release

- compatibility wrappers around better-result or tRPC types (0.3 uses
  better-result directly — the wrappers question is moot);
- exposing TanStack Query option or observer types;
- unversioned or one-sided pluggable serializers;
- automatic transmission of `Error`, stack, or cause;
- inference of wire permission from values returned by a handler;
- OpenAPI generation before the protocol and error registry stabilize;
- multiple simultaneous retry layers;
- revival of arbitrary application classes or trust in wire-supplied constructor names.
- runtime-specific wrappers around the Web Standard server adapter.

These can be revisited only if they preserve the closed, nominal-at-runtime and
structural-on-the-wire failure algebra.
